import 'package:flutter/material.dart';
import 'package:afriscouts/const/custom.dart';
class SplashScreen extends StatefulWidget {
  static const id = 'splash_screen';

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: spinkit,
    );
  }
}
