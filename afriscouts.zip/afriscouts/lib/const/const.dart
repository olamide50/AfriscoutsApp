//import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:afriscouts/const/custom.dart';
import 'package:afriscouts/screens/bookmarks_screen.dart';
import 'package:afriscouts/screens/settings_screen.dart';
import 'package:user_profile_avatar/user_profile_avatar.dart';
import 'package:afriscouts/screens/signin_screen.dart';
import 'package:afriscouts/screens/profile_screen.dart';

const String errorMessage = 'ERROR';
const String regErrorMessage = 'Error Creating User!';
const String userExistsError = 'User Already Exists!';

const String retry = 'RETRY';
const String loading = 'LOADING';
const int pageSize = 20;

Widget drawerWidget(BuildContext context) {
  return Drawer(
    child: ListView(
      // Important: Remove any padding from the ListView.
      padding: EdgeInsets.zero,
      children: <Widget>[
        Container(
          height: 300.0,
          child: DrawerHeader(
            padding: EdgeInsets.zero,
            child: Padding(
                padding: EdgeInsets.fromLTRB(10.0, 20.0, 0.0, 0.0),
                child: Column(
                  children: [
                    UserProfileAvatar(
                      avatarUrl:
                          'http://richardandbell.com/images/user-avatar-big-01.jpg',
                      onAvatarTap: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('Tapped on avatar'),
                          ),
                        );
                      },
                      notificationBubbleTextStyle: TextStyle(
                        fontSize: 30,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                      avatarSplashColor: Colors.purple,
                      radius: 60,
                      isActivityIndicatorSmall: false,
                      avatarBorderData: AvatarBorderData(
                        borderColor: Colors.redAccent,
                        borderWidth: 5.0,
                      ),
                    ),
                    /* SizedBox(height: 2.0),
                    Text('Display picture', style: TextStyle(fontSize: 12.0)) */
                    TextButton(
                      child: Text('Logout'),
                      onPressed: () {
                        Navigator.popAndPushNamed(context, SignInScreen.id);
                      },
                    )
                  ],
                )),
            decoration: BoxDecoration(
              color: Colors.blue,
            ),
          ),
        ),
        SizedBox(height: 20.0),
        CustomFlatButton(
          text: 'Bookmarks',
          onTap: () {
            Navigator.popAndPushNamed(context, BookmarksScreen.id);
          },
          icon: FaIcon(
            FontAwesomeIcons.star,
            color: Colors.yellow,
          ),
        ),
        SizedBox(height: 20.0),
        CustomFlatButton(
          text: 'Settings',
          onTap: () {
            Navigator.popAndPushNamed(context, SettingsScreen.id);
          },
          icon: FaIcon(
            FontAwesomeIcons.cog,
            color: Colors.black,
          ),
        ),
      ],
    ),
  );
}

class AppDrawer extends StatefulWidget {
  final username, password, email, userid, status, roleName, token;
  final String imageURL;

  AppDrawer(
      {@required this.email, @required this.username, @required this.imageURL, @required this.password, @required this.status, @required this.roleName, @required this.token, @required this.userid});

  @override
  _AppDrawerState createState() => _AppDrawerState();
}

class _AppDrawerState extends State<AppDrawer> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            currentAccountPicture: CircleAvatar(
              backgroundImage: NetworkImage(widget.imageURL),
            ),
            accountEmail: Text(
              widget.email,
              style: TextStyle(color: Colors.black),
            ),
            accountName: Text(
              widget.username,
              style: TextStyle(fontSize: 24.0, color: Colors.black),
            ),
            decoration: BoxDecoration(
              color: Colors.white60,
            ),
          ),
          DrawerListTile(
              icon: FaIcon(FontAwesomeIcons.user, color: Colors.black54),
              text: 'Profile',
              size: 20.0,
              onTap: () {
                Navigator.popAndPushNamed(context, ProfileScreen.id);
                Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ProfileScreen(
                                  username: widget.username,
                                  email: widget.email,
                                  userid: widget.userid,
                                  status: widget.status,
                                  roleName: widget.roleName,
                                  token: widget.token,
                                  imageURL:  widget.imageURL,
                                  password: widget.password)));
              }),
          DrawerListTile(
              icon: FaIcon(FontAwesomeIcons.bookmark, color: Colors.black54),
              text: 'Bookmarks',
              size: 20.0,
              onTap: () {
                Navigator.popAndPushNamed(context, BookmarksScreen.id);
              }),
          SizedBox(height: 25.0),
          const Divider(
            height: 10,
            thickness: 1,
          ),
          DrawerListTile(
              icon: FaIcon(FontAwesomeIcons.cog, color: Colors.black54),
              text: 'Settings',
              size: 20.0,
              onTap: () {
                Navigator.popAndPushNamed(context, SettingsScreen.id);
              }),
          DrawerListTile(
              icon: FaIcon(FontAwesomeIcons.questionCircle,
                  color: Colors.black54),
              text: 'Help',
              size: 20.0,
              onTap: () {}),
          SizedBox(height: 80),
          DrawerListTile(
              icon: FaIcon(FontAwesomeIcons.signOutAlt, color: Colors.black54),
              text: 'Logout',
              size: 20.0,
              onTap: () {
                Navigator.popAndPushNamed(context, SignInScreen.id);
              }),
        ],
      ),
    );
  }
}

class DrawerListTile extends StatefulWidget {
  final FaIcon icon;
  final String text;
  final double size;
  final Function onTap;

  DrawerListTile(
      {@required this.icon,
      @required this.text,
      @required this.size,
      @required this.onTap});

  @override
  _DrawerListTileState createState() => _DrawerListTileState();
}

class _DrawerListTileState extends State<DrawerListTile> {
  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: widget.icon,
      title: Text(
        widget.text,
        style: TextStyle(fontSize: widget.size),
      ),
      onTap: widget.onTap,
    );
  }
}
