final String getTokenURL =
    'http://134.209.73.94:8080/afriscout-api/token/generate-token';

final String registrationURL =
    'http://134.209.73.94:8080/afriscout-api/user/register';

final String authenticateUserURL =
    'http://134.209.73.94:8080/afriscout-api/login/authenticate';

final String otpURL = 'http://134.209.73.94:8080/afriscout-api/otp/generate/';

final String valOtpURL = 'http://134.209.73.94:8080/afriscout-api/otp/validate';
